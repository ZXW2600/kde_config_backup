### A dark theme created using the awesome [Nord](https://github.com/arcticicestudio/nord) color pallete.

![Nordic preview](preview/preview.png)
